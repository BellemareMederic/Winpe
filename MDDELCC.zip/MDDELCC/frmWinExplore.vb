﻿Imports System.IO 'File Operations
Imports System.Runtime.InteropServices 'APIs


Public Class frmWinExplore

    Dim strFolderName As String
    Dim WIMMounted As Boolean = False
    Dim strMountedImageLocation As String
    Dim strIndex As String
    Dim strWIM As String
    Dim strOutput As String
    Dim strDISMExitCode As String
    Dim blnDISMCommit As Boolean
    Dim strDriverLocation As String
    Dim blnForceUnsigned As Boolean
    Dim strDISMArguments As String
    Dim strPackageLocation As String
    Dim strLocation As String
    Dim blnIgnoreCheck As Boolean
    Dim strDelDriverLocation As String
    Dim strPackageName As String
    Dim strPackagePath As String
    Dim strFeatureName As String
    Dim OnlineMode As Boolean = False
    Dim strProductKey As String
    Dim strEdition As String
    Dim strXMLFileName As String
    Dim strProductCode As String
    Dim strPatchCode As String
    Dim strMSPFileName As String
    Dim strSource As String
    Dim strDest As String
    Dim strName As String
    Dim strCompression As String
    Dim strAppendIndex As String

    Private Structure SHFILEINFO 'Contains information about a file object

        Public hIcon As IntPtr            'Icon

        Public iIcon As Integer           'Icondex

        Public dwAttributes As Integer    'SFGAO_ flags

        <MarshalAs(UnmanagedType.ByValTStr, SizeConst:=260)> _
        Public szDisplayName As String

        <MarshalAs(UnmanagedType.ByValTStr, SizeConst:=80)> _
        Public szTypeName As String

    End Structure

    Private Sub version()
        lbl_version.Text = String.Format("Version {0}", My.Application.Info.Version.ToString)
        tip_help.SetToolTip(lbl_version, "Version du logiciel" + vbCrLf + "Cliquez pour obtenir des informations supplémentaires.")
    End Sub

    Private Sub block()
        txt_destination.Enabled = False
        txt_source.Enabled = False
        CheckBox1.Enabled = False
        CheckBox1.Checked = False
        CheckBox1.Text = ""
        lbl_dest_info.Text = ""
        lbl_source_info.Text = ""
        tip_help.SetToolTip(txt_destination, "Aucune information")
        tip_help.SetToolTip(txt_source, "Aucune information")
    End Sub

    Private Declare Auto Function SHGetFileInfo Lib "shell32.dll" _
            (ByVal pszPath As String, _
             ByVal dwFileAttributes As Integer, _
             ByRef psfi As SHFILEINFO, _
             ByVal cbFileInfo As Integer, _
             ByVal uFlags As Integer) As IntPtr 'Retrieves information about an object in the file system, such as a file, folder, directory, or drive root
    Private Const SHGFI_ICON = &H100 'Icon
    Private Const SHGFI_SMALLICON = &H1 'Small Icon
    Private Const SHGFI_LARGEICON = &H0    ' Large icon
    Private Const MAX_PATH = 260 'Path to Icon

    'Private Sub AddImages(ByVal strFileName As String)
    '    Try
    '        Dim shInfo As SHFILEINFO 'Create File Info Object
    '        shInfo = New SHFILEINFO() 'Instantiate File Info Object
    '        shInfo.szDisplayName = New String(vbNullChar, MAX_PATH) 'Get Display Name
    '        shInfo.szTypeName = New String(vbNullChar, 80) 'Get File Type
    '        Dim hIcon As IntPtr 'Get File Type Icon Based On File Association
    '        hIcon = SHGetFileInfo(strFileName, 0, shInfo, Marshal.SizeOf(shInfo), SHGFI_ICON Or SHGFI_SMALLICON)
    '        Dim MyIcon As Drawing.Bitmap 'Create icon
    '        MyIcon = Drawing.Icon.FromHandle(shInfo.hIcon).ToBitmap 'Set Icon
    '        iIconList.Images.Add(strFileName.ToString(), MyIcon) 'Add To ListView FileNames
    '    Catch ex As Exception
    '        Console.WriteLine(ex.Message & ex.Source)
    '        Exit Sub
    '    End Try
    'End Sub

    Private Sub AddAllFolders(ByVal TNode As TreeNode, ByVal FolderPath As String)
        Try
            For Each FolderNode As String In Directory.GetDirectories(FolderPath) 'Chargement des sous dossier 
                Dim SubFolderNode As TreeNode = TNode.Nodes.Add(FolderNode.Substring(FolderNode.LastIndexOf("\"c) + 1)) 'Chargement des sous dossier du meme dossier
                SubFolderNode.Tag = FolderNode 'Mise a jour des TAG sur les dossier
                SubFolderNode.Nodes.Add("Chargement...") 'Message de chargement pour les node
            Next
        Catch ex As Exception
            txtOutput.Text = txtOutput.Text + "erreur de dossier:" + ex.Message + vbCrLf
            REM MessageBox.Show(ex.Message) 'Si il y a des erreur sur le chargement des sous dossier les afficher.
        End Try
    End Sub

    Private Sub trvFolders_AfterSelect(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles trvFolders.AfterSelect
        Dim FileExtension As String 'On garde lextension du fichier
        Dim SubItemIndex As Integer 'on calcule le nombre de dossier
        Dim DateMod As String 'charge la date de modification
        lvFiles.Items.Clear() 'On nettoye le systeme de fichier

        If trvFolders.SelectedNode.Nodes.Count = 1 AndAlso trvFolders.SelectedNode.Nodes(0).Text = "Loading..." Then
            trvFolders.SelectedNode.Nodes.Clear() 'Nettoyage du systeme de dossier
            AddAllFolders(trvFolders.SelectedNode, CStr(trvFolders.SelectedNode.Tag))
        End If
        Dim folder As String = CStr(trvFolders.SelectedNode.Tag) 'Nom du dossier
        If Not folder Is Nothing AndAlso Directory.Exists(folder) Then
            Try
                For Each file As String In Directory.GetFiles(folder) 'Get Files In Folder
                    FileExtension = Path.GetExtension(file) 'On récupere l'extension du fichier
                    DateMod = System.IO.File.GetLastWriteTime(file).ToString() 'Get Date Modified For Each File
                    lvFiles.Items.Add(file.Substring(file.LastIndexOf("\"c) + 1), file.ToString()) 'Add Files & File Properties To ListView
                    lvFiles.Items(SubItemIndex).SubItems.Add(FileExtension.ToString())
                    lvFiles.Items(SubItemIndex).SubItems.Add(DateMod.ToString())
                    SubItemIndex += 1
                Next
            Catch ex As Exception 'Something Went Wrong
                txtOutput.Text = txtOutput.Text + "erreur de fichier:" + ex.Message + vbCrLf
            End Try
            txt_current_dir.Text = trvFolders.SelectedNode.Tag & "\" & lvFiles.Text
        End If
    End Sub

    Private Sub trvFolders_BeforeExpand(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewCancelEventArgs) Handles trvFolders.BeforeExpand
        If e.Node.Nodes.Count = 1 AndAlso e.Node.Nodes(0).Text = "Chargement..." Then
            e.Node.Nodes.Clear() 'Clear All Items
            AddAllFolders(e.Node, CStr(e.Node.Tag)) 'Add All Folders
        End If
    End Sub

    Private Sub frmWinExplore_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim drives As System.Collections.ObjectModel.ReadOnlyCollection(Of IO.DriveInfo) = My.Computer.FileSystem.Drives 'On recherche les disque possible sur le PC
        Dim rootDir As String = String.Empty
        tip_help.SetToolTip(PictureBox_refresh, "Actualiser la liste des répertoires et des disques")
        btn_diskpart.Visible = False
        btn_explorateur.Visible = False
        version()
        block()
        txtOutput.ReadOnly = True
        lbl_dest_info.Text = ""
        lbl_source_info.Text = ""
        'Now loop thru each drive and populate the treeview
        For i As Integer = 0 To drives.Count - 1 'on loop pour chaque Disque monter
            trvFolders.Sort() 'Sort Alphabetically
            Dim Tnode As TreeNode = trvFolders.Nodes.Add(drives(i).Name)
            rootDir = drives(i).Name
            'Populate this root node 
            AddAllFolders(Tnode, rootDir) 'Add All Folders 



            trvFolders.Sort() 'Sort Alphabetically
            REM OLD Dim Tnode As TreeNode = trvFolders.Nodes.Add("(Drive C:)") 'Add Main Node
            REM OLD AddAllFolders(Tnode, "C:\") 'Add All Folders 
            lvFiles.View = View.Details 'Set View of ListView
        Next
        ' Add ListView Columns With Specified Width
        lvFiles.Columns.Clear()
        lvFiles.Columns.Add("Nom fichier", 150, HorizontalAlignment.Left)
        lvFiles.Columns.Add("Type fichier", 80, HorizontalAlignment.Left)
        lvFiles.Columns.Add("Date de modif", 150, HorizontalAlignment.Left)
        If File.Exists("x:\outils\DiskPartitioner.exe") Then
            btn_diskpart.Visible = True
        End If
        If File.Exists("X:\outils\FreeCommander\FreeCommander.exe") Then
            btn_explorateur.Visible = True
        End If


    End Sub

    Private Sub CopyToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles sourToolStripMenuItem.Click
        txt_source.Text = trvFolders.SelectedNode.Tag 'On recupaire le dossier 
        Dim lvItem As ListViewItem 'ListView item
        Dim lvSel As ListView.SelectedListViewItemCollection = Me.lvFiles.SelectedItems 'ListViewItems
        Dim strFileName As String 'File Name
        For Each lvItem In lvSel 'Si ce n'est pas un dossier mais un ou des fichier on les loop
            strFileName = trvFolders.SelectedNode.Tag & "\" & lvItem.Text 'Get Selected File Name
            txt_source.Text = strFileName
        Next
    End Sub

    Private Sub PasteToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles destToolStripMenuItem.Click
        txt_destination.Text = trvFolders.SelectedNode.Tag 'On recupaire le dossier 
        Dim lvItem As ListViewItem 'ListView item
        Dim lvSel As ListView.SelectedListViewItemCollection = Me.lvFiles.SelectedItems 'ListViewItems
        Dim strFileName As String 'Nom du fichier
        For Each lvItem In lvSel 'Si ce n'est pas un dossier mais un ou des fichier on les loop
            strFileName = trvFolders.SelectedNode.Tag & "\" & lvItem.Text 'Get Selected File Name
            txt_destination.Text = strFileName
        Next
    End Sub

    Private Sub cboView_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboView.SelectedIndexChanged
        Dim strSelView = CType(cboView.SelectedItem, String) 'Change ListView ViewMode
        Select Case strSelView
            Case "Details"
                lvFiles.View = View.Details
            Case "Small Icon"
                lvFiles.View = View.SmallIcon
            Case "List"
                lvFiles.View = View.List
        End Select
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Application.Exit() 'Exit
    End Sub

    Private Sub BackgroundWorkerMount_DoWork(ByVal sender As System.Object, ByVal e As System.ComponentModel.DoWorkEventArgs) Handles BackgroundWorkerMount.DoWork
        strDISMExitCode = ""
        'Mount WIM file
        Dim DISM As New Process()
        DISM.StartInfo.RedirectStandardOutput = True
        DISM.StartInfo.RedirectStandardError = True
        DISM.StartInfo.UseShellExecute = False
        DISM.StartInfo.CreateNoWindow = True
        DISM.StartInfo.FileName = "dism.exe"
        DISM.StartInfo.Arguments = "/Mount-WIM /WimFile:""" & strWIM & """" & " /index:" & strIndex & " /MountDir:" & """" & strFolderName & """"
        strOutput = "La commande est exécutée par dism.exe " & DISM.StartInfo.Arguments
        DISM.Start()
        strOutput = strOutput & vbCr & vbCr & DISM.StandardOutput.ReadToEnd()
        DISM.WaitForExit()
        'txtOutput.Text = output
        strDISMExitCode = DISM.ExitCode
    End Sub

    Private Sub BackgroundWorkerDisMount_DoWork(ByVal sender As System.Object, ByVal e As System.ComponentModel.DoWorkEventArgs) Handles BackgroundWorkerDisMount.DoWork
        strDISMExitCode = ""

        If MessageBox.Show("Voulez-vous enregistrer les modification?", "WIM Mounted", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
            blnDISMCommit = True
        Else
            blnDISMCommit = False
        End If


        Dim DISM As New Process()
        DISM.StartInfo.RedirectStandardOutput = True
        DISM.StartInfo.RedirectStandardError = True
        DISM.StartInfo.UseShellExecute = False
        DISM.StartInfo.CreateNoWindow = True
        DISM.StartInfo.FileName = "dism.exe"

        If blnDISMCommit = True Then
            DISM.StartInfo.Arguments = "/Unmount-wim /mountdir:""" & strFolderName & """ /commit"
            strOutput = "La commande est exécutée par dism.exe " & DISM.StartInfo.Arguments
            DISM.Start()
        Else
            DISM.StartInfo.Arguments = "/Unmount-wim /mountdir:""" & strFolderName & """ /discard"
            strOutput = "La commande est exécutée par dism.exe " & DISM.StartInfo.Arguments
            DISM.Start()
        End If

        strOutput = strOutput & vbCr & vbCr & DISM.StandardOutput.ReadToEnd()
        DISM.WaitForExit()
        strDISMExitCode = DISM.ExitCode
    End Sub

    Private Sub BackgroundWorkerDISMCommand_DoWork(ByVal sender As System.Object, ByVal e As System.ComponentModel.DoWorkEventArgs) Handles BackgroundWorkerDISMCommand.DoWork
        Dim strInput As String = e.Argument
        strDISMExitCode = ""
        Dim DISM As New Process()
        DISM.StartInfo.RedirectStandardOutput = True
        DISM.StartInfo.RedirectStandardError = True
        DISM.StartInfo.UseShellExecute = False
        DISM.StartInfo.CreateNoWindow = True
        DISM.StartInfo.FileName = "dism.exe"
        DISM.StartInfo.Arguments = strInput
        strOutput = "La commande est exécutée par dism.exe " & DISM.StartInfo.Arguments
        DISM.Start()
        strOutput = strOutput & vbCr & vbCr & DISM.StandardOutput.ReadToEnd()
        DISM.WaitForExit()
        strDISMExitCode = DISM.ExitCode
    End Sub

    Private Sub btn_mount_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_mount.Click
        txtOutput.Text = ""
        If txt_source.Text = "" Or txt_destination.Text = "" Then
            MsgBox("Vous devez selectionner votre image WIM")
        Else
            If Directory.GetFiles(txt_destination.Text).Length = 0 And Directory.GetDirectories(txt_destination.Text).Length = 0 Then
                txt_destination.Text = Replace(txt_destination.Text, """", "")
                strFolderName = txt_destination.Text
                strIndex = 1
                txt_source.Text = Replace(txt_source.Text, """", "")
                strWIM = txt_source.Text
                BackgroundWorkerMount.RunWorkerAsync()
                frmloading.ShowDialog()
                txtOutput.Text = strOutput
            Else
                If MessageBox.Show("Le repertoire n'est pas vide." + vbCrLf + "Voulez-vous en créer un vide?", "Impossible", MessageBoxButtons.YesNo) = vbYes Then
                    If Directory.Exists(txt_destination.Text + "\mount") Then
                        MessageBox.Show("Le dossier mount est déjà utilisé veuillez le vider.")
                    Else
                        Directory.CreateDirectory(txt_destination.Text + "\mount")
                        txt_destination.Text = txt_destination.Text + "\mount"
                        txt_destination.Text = Replace(txt_destination.Text, """", "")
                        strFolderName = txt_destination.Text
                        strIndex = 1
                        txt_source.Text = Replace(txt_source.Text, """", "")
                        strWIM = txt_source.Text
                        BackgroundWorkerMount.RunWorkerAsync()
                        frmloading.ShowDialog()
                        txtOutput.Text = strOutput
                    End If
                End If
            End If
        End If
    End Sub

    Private Sub btn_dismount_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_dismount.Click
        strFolderName = txt_destination.Text
        strIndex = 1
        strWIM = txt_source.Text
        txtOutput.Text = ""
        BackgroundWorkerDisMount.RunWorkerAsync()
        frmloading.ShowDialog()
        txtOutput.Text = strOutput
    End Sub

    Private Sub BackgroundWorkerMount_RunWorkerCompleted(ByVal sender As System.Object, ByVal e As System.ComponentModel.RunWorkerCompletedEventArgs) Handles BackgroundWorkerMount.RunWorkerCompleted
        'Check to see if WIM mounted correctly
        If strDISMExitCode = "0" Then
            btn_mount.Enabled = False
            btn_dismount.Enabled = True
            WIMMounted = True

            If strMountedImageLocation = "" Then
                strMountedImageLocation = strFolderName
            Else
                'Do Nothing
            End If
            frmloading.Close()
            Me.Enabled = True
        Else
            frmloading.Close()
            Me.Enabled = True
        End If
        Me.Enabled = True
    End Sub

    Private Sub BackgroundWorkerDisMount_RunWorkerCompleted(ByVal sender As System.Object, ByVal e As System.ComponentModel.RunWorkerCompletedEventArgs) Handles BackgroundWorkerDisMount.RunWorkerCompleted
        If strDISMExitCode = "0" Then
            btn_mount.Enabled = True
            btn_dismount.Enabled = False
            WIMMounted = False
            strMountedImageLocation = ""
            frmloading.Close()
            Me.Enabled = True
        Else
            frmloading.Close()
            Me.Enabled = True
        End If
        Me.Enabled = True
    End Sub

    Private Sub BackgroundWorkerDISMCommand_RunWorkerCompleted(ByVal sender As System.Object, ByVal e As System.ComponentModel.RunWorkerCompletedEventArgs) Handles BackgroundWorkerDISMCommand.RunWorkerCompleted
        strDISMArguments = ""
        frmloading.Close()
        Me.Enabled = True
    End Sub
    REM BUTTON OVER SUB===========================================
    Private Sub btn_dismount_MouseHover(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_dismount.MouseHover
        block()
        lbl_dest_info.Text = "Répertoire"
        tip_help.SetToolTip(txt_destination, "Indiquez le dossier qui dois etre démonté")
        lbl_source_info.Text = ""
        txt_destination.Enabled = True
    End Sub

    Private Sub btn_mount_MouseHover(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_mount.MouseHover
        block()
        lbl_dest_info.Text = "Répertoire"
        lbl_source_info.Text = "Fichier Wim"
        tip_help.SetToolTip(txt_destination, "Indiquez le dossier qui servira à monter l'image WIM")
        tip_help.SetToolTip(txt_source, "Indiquez le fichier WIM qui doit être monté dans le repertoire")
        txt_source.Enabled = True
        txt_destination.Enabled = True
    End Sub

    Private Sub btn_sauv_MouseHover(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_sauv.MouseHover
        block()
        lbl_dest_info.Text = "Répertoire"
        lbl_source_info.Text = "Racine Windows"
        CheckBox1.Text = "Vérifier?"
        tip_help.SetToolTip(txt_destination, "Indiquez le dossier de sortie de la capture")
        tip_help.SetToolTip(txt_source, "Indiquez la racine système que vous voulez sauvgarder" + vbCrLf + "Ex:(C:\)ou(E:\)")
        tip_help.SetToolTip(CheckBox1, "Indiquez si vous voulez que l'image soit vérifiée à la fin de sa creation")
        CheckBox1.Enabled = True
        txt_source.Enabled = True
        txt_destination.Enabled = True
    End Sub
    REM BUTTON OVER SUB=========================================== end

    Private Sub btn_sauv_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_sauv.Click
        strName = ""
        strDest = ""
        strSource = ""
        If txt_source.Text = "" Then
            MessageBox.Show("Vous devez indiquer la source.")
            Exit Sub
        End If

        If txt_destination.Text = "" Then
            MessageBox.Show("Vous devez choisir un repertoire de sortie.")
            Exit Sub
        End If

        If MessageBox.Show("Avez-vous fait votre sysprep?", "Confirmation", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
            Do Until strName <> ""

                strName = InputBox("Entrer le nom de l'image", "Nom d'image")


            Loop
            strName += ".WIM"
            strSource = txt_source.Text
            strDest = txt_destination.Text & strName
            strCompression = "Fast"

            If CheckBox1.Checked = True Then
                strDISMArguments = "/Capture-Image /ImageFile:" + strDest + " /CaptureDir:" + strSource + " /Name:" + Chr(34) + strName + Chr(34) + " /Compress:" + strCompression + " /verify"
            Else
                strDISMArguments = "/Capture-Image /ImageFile:" + strDest + " /CaptureDir:" + strSource + " /Name:" + Chr(34) + strName + Chr(34) + " /Compress:" + strCompression
            End If


            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmloading.ShowDialog()
            txtOutput.Text = strOutput
        Else
            MessageBox.Show("Veuillez retourner sur votre windows et exécuter le sysprep", "Sysprep?", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If

    End Sub

    Private Sub frmWinExplore_MouseDoubleClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseDoubleClick
        Me.Enabled = True
    End Sub

    Private Sub btn_re_MouseHover(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_re.MouseHover
        block()
        lbl_dest_info.Text = "Racine Windows"
        lbl_source_info.Text = "Fichier WIM"
        CheckBox1.Text = "Vérifier?"
        tip_help.SetToolTip(txt_destination, "Indiquer la racine pour l'image Wim doit être déployée" + vbCrLf + "ex:(C:\) ou (E:\)")
        tip_help.SetToolTip(txt_source, "Indiquer le fichier WIM à déployer")
        tip_help.SetToolTip(CheckBox1, "Indiquer si vous voulez que l'installation soit vérifiée à la fin")
        CheckBox1.Enabled = True
        txt_source.Enabled = True
        txt_destination.Enabled = True
    End Sub

    Private Sub btn_re_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_re.Click
        strFolderName = ""
        strSource = ""
        strDest = ""
        If txt_source.Text = "" Then
            MessageBox.Show("Vous devez sélectionner votre WIM.")
            Exit Sub
        Else
            'Do Nothing
        End If

        If txt_destination.Text = "" Then
            MessageBox.Show("Vous devez sélectionner votre répertoire de sortie.")
            Exit Sub
        Else
            'Do Nothing
        End If

        strAppendIndex = 1

        strFolderName = txt_destination.Text
        If strFolderName.EndsWith("\") Then
            'Do Nothing
        Else
            strFolderName = strFolderName & "\"
            txt_destination.Text = strFolderName
        End If

        strSource = txt_source.Text
        strDest = txt_destination.Text


        If CheckBox1.Checked = True Then
            strDISMArguments = "/Apply-Image /ImageFile:" & strSource & " /index:" & strAppendIndex & " /ApplyDir:" & strDest & " /Verify"
        Else
            strDISMArguments = "/Apply-Image /ImageFile:" & strSource & " /index:" & strAppendIndex & " /ApplyDir:" & strDest & ""
        End If
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmloading.ShowDialog()
        txtOutput.Text = strOutput

    End Sub

    Private Sub btn_adv_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_adv.Click
        strDISMArguments = InputBox("Entrer les argument DISM (/Capture-Image /ImageFile:C:\wim.wim /CaptureDir:C:\ /Name:windows7image /Compress:FAST /verify)", "TeknixDISM ADV console")
        If Not strDISMArguments = "" Then
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmloading.ShowDialog()
            txtOutput.Text = strOutput
        End If
    End Sub

    Private Sub lvFiles_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lvFiles.SelectedIndexChanged
        Dim lvItem As ListViewItem 'ListView item
        Dim lvSel As ListView.SelectedListViewItemCollection = Me.lvFiles.SelectedItems 'ListViewItems
        For Each lvItem In lvSel 'Loop Through Select File Names In ListView
            txt_current_dir.Text = trvFolders.SelectedNode.Tag & "\" & lvItem.Text 'Get Selected File Name
        Next
    End Sub


    Private Sub lbl_version_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lbl_version.Click
        About.Show()
    End Sub


    Public Sub PictureBox2_Click(sender As System.Object, e As System.EventArgs) Handles PictureBox_refresh.Click
        trvFolders.Nodes.Clear()
        lvFiles.Clear()
        txt_current_dir.Clear()
        frmWinExplore_Load(e, e)
    End Sub

    Private Sub btn_diskpart_Click(sender As System.Object, e As System.EventArgs) Handles btn_diskpart.Click
        Process.Start("x:\outils\DiskPartitioner.exe")
    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        netconnect.Show()
        netconnect.Focus()
    End Sub

    Private Sub btn_explorateur_Click(sender As System.Object, e As System.EventArgs) Handles btn_explorateur.Click
        Process.Start("X:\outils\FreeCommander\FreeCommander.exe")
    End Sub
End Class
