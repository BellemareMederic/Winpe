﻿Public Class frmloading
    Dim Progress As Integer


    Private Sub frmProgress_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Timer1.Enabled = True
        ProgressBar1.MarqueeAnimationSpeed = 100
    End Sub

    Private Sub ProgressBar1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ProgressBar1.Click
        If ProgressBar1.MarqueeAnimationSpeed <> 10 Then
            ProgressBar1.MarqueeAnimationSpeed -= 10
        End If

    End Sub
End Class