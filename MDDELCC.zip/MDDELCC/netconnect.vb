﻿Public Class netconnect
    Dim outputerror As String
    Dim strNETUSEExitCode As String
    Dim stroutput As String
    Dim argument As String

    Private Sub btn_connect_netuse_Click(sender As System.Object, e As System.EventArgs) Handles btn_connect_netuse.Click

        argument = "/c net use " & CB_letter.SelectedItem & " \\" & txt_source.Text & " /user:" & txt_domain.Text & "\" & txt_user.Text & " " & txt_password.Text
        netusework.RunWorkerAsync(argument)
        frmloading.ShowDialog()
        REM System.Diagnostics.Process.Start("cmd.exe", "/c net use " & CB_letter.SelectedItem & " \\" & txt_source.Text & " /user:" & txt_domain.Text & "\" & txt_user.Text & " " & txt_password.Text)
    End Sub

    Private Sub BackgroundWorker1_DoWork(sender As System.Object, e As System.ComponentModel.DoWorkEventArgs) Handles netusework.DoWork
        Dim strInput As String = e.Argument
        strNETUSEExitCode = ""
        Dim DISM As New Process()
        DISM.StartInfo.RedirectStandardOutput = True
        DISM.StartInfo.RedirectStandardError = True
        DISM.StartInfo.UseShellExecute = False
        DISM.StartInfo.CreateNoWindow = True
        DISM.StartInfo.FileName = "cmd"
        DISM.StartInfo.Arguments = strInput
        stroutput = "Chargement de : " & DISM.StartInfo.Arguments
        DISM.Start()
        stroutput = stroutput & vbCr & vbCr & DISM.StandardOutput.ReadToEnd()
        DISM.WaitForExit()
        strNETUSEExitCode = stroutput & vbCrLf & "Code :" & DISM.ExitCode
    End Sub

    Private Sub netusework_RunWorkerCompleted(sender As System.Object, e As System.ComponentModel.RunWorkerCompletedEventArgs) Handles netusework.RunWorkerCompleted
        txtr_output.Text = strNETUSEExitCode
        frmloading.Close()
    End Sub
End Class