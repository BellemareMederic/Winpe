﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class netconnect
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(netconnect))
        Me.txt_domain = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txt_user = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txt_password = New System.Windows.Forms.TextBox()
        Me.btn_connect_netuse = New System.Windows.Forms.Button()
        Me.CB_letter = New System.Windows.Forms.ComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txt_source = New System.Windows.Forms.TextBox()
        Me.netusework = New System.ComponentModel.BackgroundWorker()
        Me.txtr_output = New System.Windows.Forms.RichTextBox()
        Me.SuspendLayout()
        '
        'txt_domain
        '
        Me.txt_domain.Location = New System.Drawing.Point(89, 9)
        Me.txt_domain.Name = "txt_domain"
        Me.txt_domain.Size = New System.Drawing.Size(175, 20)
        Me.txt_domain.TabIndex = 0
        Me.txt_domain.Text = "prod"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(3, 12)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(52, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Domaine:"
        '
        'txt_user
        '
        Me.txt_user.Location = New System.Drawing.Point(89, 31)
        Me.txt_user.Name = "txt_user"
        Me.txt_user.Size = New System.Drawing.Size(175, 20)
        Me.txt_user.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(3, 34)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(79, 13)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Nom utilisateur:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(3, 56)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(73, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "mot de passe:"
        '
        'txt_password
        '
        Me.txt_password.Location = New System.Drawing.Point(89, 53)
        Me.txt_password.Name = "txt_password"
        Me.txt_password.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txt_password.Size = New System.Drawing.Size(175, 20)
        Me.txt_password.TabIndex = 2
        '
        'btn_connect_netuse
        '
        Me.btn_connect_netuse.Location = New System.Drawing.Point(6, 126)
        Me.btn_connect_netuse.Name = "btn_connect_netuse"
        Me.btn_connect_netuse.Size = New System.Drawing.Size(258, 23)
        Me.btn_connect_netuse.TabIndex = 6
        Me.btn_connect_netuse.Text = "Connecter"
        Me.btn_connect_netuse.UseVisualStyleBackColor = True
        '
        'CB_letter
        '
        Me.CB_letter.FormattingEnabled = True
        Me.CB_letter.ItemHeight = 13
        Me.CB_letter.Items.AddRange(New Object() {"A:", "B:", "C:", "D:", "E:", "F:", "G:", "H:", "I:", "K:", "L:", "M:", "N:", "O:", "P:", "Q:", "R:", "S:", "T:", "U:", "V:", "W:", "X:", "Y:", "Z:", "*"})
        Me.CB_letter.Location = New System.Drawing.Point(89, 99)
        Me.CB_letter.Name = "CB_letter"
        Me.CB_letter.Size = New System.Drawing.Size(46, 21)
        Me.CB_letter.TabIndex = 5
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(3, 102)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(37, 13)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "Lettre:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(3, 79)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(74, 13)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "Emplacement:"
        '
        'txt_source
        '
        Me.txt_source.Location = New System.Drawing.Point(89, 76)
        Me.txt_source.Name = "txt_source"
        Me.txt_source.Size = New System.Drawing.Size(175, 20)
        Me.txt_source.TabIndex = 3
        '
        'netusework
        '
        '
        'txtr_output
        '
        Me.txtr_output.Location = New System.Drawing.Point(6, 155)
        Me.txtr_output.Name = "txtr_output"
        Me.txtr_output.Size = New System.Drawing.Size(258, 118)
        Me.txtr_output.TabIndex = 12
        Me.txtr_output.Text = ""
        '
        'netconnect
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(269, 280)
        Me.Controls.Add(Me.txtr_output)
        Me.Controls.Add(Me.txt_source)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.CB_letter)
        Me.Controls.Add(Me.btn_connect_netuse)
        Me.Controls.Add(Me.txt_password)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txt_user)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txt_domain)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "netconnect"
        Me.Text = "netconnect"
        Me.TopMost = True
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txt_domain As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txt_user As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txt_password As System.Windows.Forms.TextBox
    Friend WithEvents btn_connect_netuse As System.Windows.Forms.Button
    Friend WithEvents CB_letter As System.Windows.Forms.ComboBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txt_source As System.Windows.Forms.TextBox
    Friend WithEvents netusework As System.ComponentModel.BackgroundWorker
    Friend WithEvents txtr_output As System.Windows.Forms.RichTextBox
End Class
