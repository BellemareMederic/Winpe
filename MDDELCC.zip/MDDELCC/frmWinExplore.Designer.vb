﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmWinExplore
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmWinExplore))
        Me.lvFiles = New System.Windows.Forms.ListView()
        Me.cmClipboardOp = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.sourToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.destToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.iIconList = New System.Windows.Forms.ImageList(Me.components)
        Me.trvFolders = New System.Windows.Forms.TreeView()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.cboView = New System.Windows.Forms.ComboBox()
        Me.txt_source = New System.Windows.Forms.TextBox()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.SplitContainer2 = New System.Windows.Forms.SplitContainer()
        Me.txt_current_dir = New System.Windows.Forms.TextBox()
        Me.btn_explorateur = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.btn_diskpart = New System.Windows.Forms.Button()
        Me.PictureBox_refresh = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.btn_adv = New System.Windows.Forms.Button()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.lbl_version = New System.Windows.Forms.Label()
        Me.lbl_source_info = New System.Windows.Forms.Label()
        Me.lbl_dest_info = New System.Windows.Forms.Label()
        Me.txtOutput = New System.Windows.Forms.TextBox()
        Me.btn_dismount = New System.Windows.Forms.Button()
        Me.btn_mount = New System.Windows.Forms.Button()
        Me.btn_re = New System.Windows.Forms.Button()
        Me.btn_sauv = New System.Windows.Forms.Button()
        Me.txt_destination = New System.Windows.Forms.TextBox()
        Me.lbl_destination = New System.Windows.Forms.Label()
        Me.lbl_source = New System.Windows.Forms.Label()
        Me.BackgroundWorkerDISMCommand = New System.ComponentModel.BackgroundWorker()
        Me.BackgroundWorkerDisMount = New System.ComponentModel.BackgroundWorker()
        Me.BackgroundWorkerMount = New System.ComponentModel.BackgroundWorker()
        Me.tip_help = New System.Windows.Forms.ToolTip(Me.components)
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.cmClipboardOp.SuspendLayout()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        CType(Me.SplitContainer2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer2.Panel1.SuspendLayout()
        Me.SplitContainer2.Panel2.SuspendLayout()
        Me.SplitContainer2.SuspendLayout()
        CType(Me.PictureBox_refresh, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lvFiles
        '
        Me.lvFiles.ContextMenuStrip = Me.cmClipboardOp
        Me.lvFiles.Location = New System.Drawing.Point(0, 0)
        Me.lvFiles.Name = "lvFiles"
        Me.lvFiles.Size = New System.Drawing.Size(472, 222)
        Me.lvFiles.SmallImageList = Me.iIconList
        Me.lvFiles.TabIndex = 4
        Me.lvFiles.UseCompatibleStateImageBehavior = False
        '
        'cmClipboardOp
        '
        Me.cmClipboardOp.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.sourToolStripMenuItem, Me.destToolStripMenuItem})
        Me.cmClipboardOp.Name = "cmClipboardOp"
        Me.cmClipboardOp.Size = New System.Drawing.Size(218, 48)
        '
        'sourToolStripMenuItem
        '
        Me.sourToolStripMenuItem.Name = "sourToolStripMenuItem"
        Me.sourToolStripMenuItem.Size = New System.Drawing.Size(217, 22)
        Me.sourToolStripMenuItem.Text = "Sélectionner la source"
        '
        'destToolStripMenuItem
        '
        Me.destToolStripMenuItem.Name = "destToolStripMenuItem"
        Me.destToolStripMenuItem.Size = New System.Drawing.Size(217, 22)
        Me.destToolStripMenuItem.Text = "Sélectrionner la destination"
        '
        'iIconList
        '
        Me.iIconList.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.iIconList.ImageSize = New System.Drawing.Size(16, 16)
        Me.iIconList.TransparentColor = System.Drawing.Color.Transparent
        '
        'trvFolders
        '
        Me.trvFolders.ContextMenuStrip = Me.cmClipboardOp
        Me.trvFolders.Dock = System.Windows.Forms.DockStyle.Fill
        Me.trvFolders.Location = New System.Drawing.Point(0, 0)
        Me.trvFolders.Name = "trvFolders"
        Me.trvFolders.Size = New System.Drawing.Size(247, 248)
        Me.trvFolders.TabIndex = 3
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(645, 218)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 6
        Me.btnExit.Text = "Fermer"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'cboView
        '
        Me.cboView.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cboView.FormattingEnabled = True
        Me.cboView.Items.AddRange(New Object() {"Details", "Small Icon", "List"})
        Me.cboView.Location = New System.Drawing.Point(351, 227)
        Me.cboView.Name = "cboView"
        Me.cboView.Size = New System.Drawing.Size(121, 21)
        Me.cboView.TabIndex = 7
        '
        'txt_source
        '
        Me.txt_source.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txt_source.Location = New System.Drawing.Point(72, 32)
        Me.txt_source.Name = "txt_source"
        Me.txt_source.Size = New System.Drawing.Size(502, 20)
        Me.txt_source.TabIndex = 8
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer1.Name = "SplitContainer1"
        Me.SplitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.SplitContainer2)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.btn_explorateur)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Button1)
        Me.SplitContainer1.Panel2.Controls.Add(Me.btn_diskpart)
        Me.SplitContainer1.Panel2.Controls.Add(Me.PictureBox_refresh)
        Me.SplitContainer1.Panel2.Controls.Add(Me.PictureBox1)
        Me.SplitContainer1.Panel2.Controls.Add(Me.btn_adv)
        Me.SplitContainer1.Panel2.Controls.Add(Me.CheckBox1)
        Me.SplitContainer1.Panel2.Controls.Add(Me.lbl_version)
        Me.SplitContainer1.Panel2.Controls.Add(Me.lbl_source_info)
        Me.SplitContainer1.Panel2.Controls.Add(Me.lbl_dest_info)
        Me.SplitContainer1.Panel2.Controls.Add(Me.txtOutput)
        Me.SplitContainer1.Panel2.Controls.Add(Me.btn_dismount)
        Me.SplitContainer1.Panel2.Controls.Add(Me.btn_mount)
        Me.SplitContainer1.Panel2.Controls.Add(Me.btn_re)
        Me.SplitContainer1.Panel2.Controls.Add(Me.btn_sauv)
        Me.SplitContainer1.Panel2.Controls.Add(Me.txt_destination)
        Me.SplitContainer1.Panel2.Controls.Add(Me.lbl_destination)
        Me.SplitContainer1.Panel2.Controls.Add(Me.lbl_source)
        Me.SplitContainer1.Panel2.Controls.Add(Me.txt_source)
        Me.SplitContainer1.Panel2.Controls.Add(Me.btnExit)
        Me.SplitContainer1.Size = New System.Drawing.Size(723, 496)
        Me.SplitContainer1.SplitterDistance = 248
        Me.SplitContainer1.TabIndex = 9
        '
        'SplitContainer2
        '
        Me.SplitContainer2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer2.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer2.Name = "SplitContainer2"
        '
        'SplitContainer2.Panel1
        '
        Me.SplitContainer2.Panel1.Controls.Add(Me.trvFolders)
        '
        'SplitContainer2.Panel2
        '
        Me.SplitContainer2.Panel2.Controls.Add(Me.cboView)
        Me.SplitContainer2.Panel2.Controls.Add(Me.lvFiles)
        Me.SplitContainer2.Panel2.Controls.Add(Me.txt_current_dir)
        Me.SplitContainer2.Size = New System.Drawing.Size(723, 248)
        Me.SplitContainer2.SplitterDistance = 247
        Me.SplitContainer2.TabIndex = 7
        '
        'txt_current_dir
        '
        Me.txt_current_dir.Location = New System.Drawing.Point(0, 227)
        Me.txt_current_dir.Multiline = True
        Me.txt_current_dir.Name = "txt_current_dir"
        Me.txt_current_dir.Size = New System.Drawing.Size(351, 21)
        Me.txt_current_dir.TabIndex = 8
        '
        'btn_explorateur
        '
        Me.btn_explorateur.Location = New System.Drawing.Point(580, 173)
        Me.btn_explorateur.Name = "btn_explorateur"
        Me.btn_explorateur.Size = New System.Drawing.Size(137, 23)
        Me.btn_explorateur.TabIndex = 27
        Me.btn_explorateur.Text = "Explorateur de fichier"
        Me.btn_explorateur.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(580, 127)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(137, 23)
        Me.Button1.TabIndex = 26
        Me.Button1.Tag = ""
        Me.Button1.Text = "Lecteur Réseau"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'btn_diskpart
        '
        Me.btn_diskpart.Location = New System.Drawing.Point(580, 150)
        Me.btn_diskpart.Name = "btn_diskpart"
        Me.btn_diskpart.Size = New System.Drawing.Size(137, 23)
        Me.btn_diskpart.TabIndex = 25
        Me.btn_diskpart.Text = "Gestion des disques"
        Me.btn_diskpart.UseVisualStyleBackColor = True
        '
        'PictureBox_refresh
        '
        Me.PictureBox_refresh.Image = Global.WimApp.My.Resources.Resources._614326_refresh_2_512
        Me.PictureBox_refresh.Location = New System.Drawing.Point(4, -1)
        Me.PictureBox_refresh.Name = "PictureBox_refresh"
        Me.PictureBox_refresh.Size = New System.Drawing.Size(27, 28)
        Me.PictureBox_refresh.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox_refresh.TabIndex = 24
        Me.PictureBox_refresh.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.WimApp.My.Resources.Resources.MDDELCCCinb
        Me.PictureBox1.Location = New System.Drawing.Point(326, 104)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(248, 128)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 22
        Me.PictureBox1.TabStop = False
        '
        'btn_adv
        '
        Me.btn_adv.Location = New System.Drawing.Point(580, 104)
        Me.btn_adv.Name = "btn_adv"
        Me.btn_adv.Size = New System.Drawing.Size(137, 23)
        Me.btn_adv.TabIndex = 21
        Me.btn_adv.Text = "Mode Avancé"
        Me.btn_adv.UseVisualStyleBackColor = True
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Enabled = False
        Me.CheckBox1.Location = New System.Drawing.Point(326, 84)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox1.TabIndex = 20
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'lbl_version
        '
        Me.lbl_version.AutoSize = True
        Me.lbl_version.Location = New System.Drawing.Point(642, 202)
        Me.lbl_version.Name = "lbl_version"
        Me.lbl_version.Size = New System.Drawing.Size(39, 13)
        Me.lbl_version.TabIndex = 19
        Me.lbl_version.Text = "Label3"
        '
        'lbl_source_info
        '
        Me.lbl_source_info.AutoSize = True
        Me.lbl_source_info.Location = New System.Drawing.Point(580, 35)
        Me.lbl_source_info.Name = "lbl_source_info"
        Me.lbl_source_info.Size = New System.Drawing.Size(39, 13)
        Me.lbl_source_info.TabIndex = 18
        Me.lbl_source_info.Text = "Label3"
        '
        'lbl_dest_info
        '
        Me.lbl_dest_info.AutoSize = True
        Me.lbl_dest_info.Location = New System.Drawing.Point(580, 58)
        Me.lbl_dest_info.Name = "lbl_dest_info"
        Me.lbl_dest_info.Size = New System.Drawing.Size(39, 13)
        Me.lbl_dest_info.TabIndex = 17
        Me.lbl_dest_info.Text = "Label3"
        '
        'txtOutput
        '
        Me.txtOutput.Location = New System.Drawing.Point(6, 81)
        Me.txtOutput.Multiline = True
        Me.txtOutput.Name = "txtOutput"
        Me.txtOutput.Size = New System.Drawing.Size(314, 156)
        Me.txtOutput.TabIndex = 16
        '
        'btn_dismount
        '
        Me.btn_dismount.Location = New System.Drawing.Point(199, 3)
        Me.btn_dismount.Name = "btn_dismount"
        Me.btn_dismount.Size = New System.Drawing.Size(121, 23)
        Me.btn_dismount.TabIndex = 15
        Me.btn_dismount.Text = "Démonter"
        Me.btn_dismount.UseVisualStyleBackColor = True
        '
        'btn_mount
        '
        Me.btn_mount.Location = New System.Drawing.Point(72, 3)
        Me.btn_mount.Name = "btn_mount"
        Me.btn_mount.Size = New System.Drawing.Size(121, 23)
        Me.btn_mount.TabIndex = 14
        Me.btn_mount.Text = "Monter"
        Me.btn_mount.UseVisualStyleBackColor = True
        '
        'btn_re
        '
        Me.btn_re.Location = New System.Drawing.Point(453, 3)
        Me.btn_re.Name = "btn_re"
        Me.btn_re.Size = New System.Drawing.Size(121, 23)
        Me.btn_re.TabIndex = 13
        Me.btn_re.Text = "Appliquer une image"
        Me.btn_re.UseVisualStyleBackColor = True
        '
        'btn_sauv
        '
        Me.btn_sauv.Location = New System.Drawing.Point(326, 3)
        Me.btn_sauv.Name = "btn_sauv"
        Me.btn_sauv.Size = New System.Drawing.Size(121, 23)
        Me.btn_sauv.TabIndex = 12
        Me.btn_sauv.Text = "Capturer une image"
        Me.btn_sauv.UseVisualStyleBackColor = True
        '
        'txt_destination
        '
        Me.txt_destination.Location = New System.Drawing.Point(72, 55)
        Me.txt_destination.Name = "txt_destination"
        Me.txt_destination.Size = New System.Drawing.Size(502, 20)
        Me.txt_destination.TabIndex = 11
        '
        'lbl_destination
        '
        Me.lbl_destination.AutoSize = True
        Me.lbl_destination.Location = New System.Drawing.Point(3, 58)
        Me.lbl_destination.Name = "lbl_destination"
        Me.lbl_destination.Size = New System.Drawing.Size(66, 13)
        Me.lbl_destination.TabIndex = 10
        Me.lbl_destination.Text = "Destination :"
        '
        'lbl_source
        '
        Me.lbl_source.AutoSize = True
        Me.lbl_source.Location = New System.Drawing.Point(8, 35)
        Me.lbl_source.Name = "lbl_source"
        Me.lbl_source.Size = New System.Drawing.Size(47, 13)
        Me.lbl_source.TabIndex = 9
        Me.lbl_source.Text = "Source :"
        '
        'BackgroundWorkerDISMCommand
        '
        '
        'BackgroundWorkerDisMount
        '
        '
        'BackgroundWorkerMount
        '
        '
        'tip_help
        '
        Me.tip_help.AutoPopDelay = 5000
        Me.tip_help.InitialDelay = 30
        Me.tip_help.ReshowDelay = 100
        '
        'frmWinExplore
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(725, 496)
        Me.Controls.Add(Me.SplitContainer1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "frmWinExplore"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "WimApp Par Médéric Bellemare"
        Me.cmClipboardOp.ResumeLayout(False)
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        Me.SplitContainer1.Panel2.PerformLayout()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        Me.SplitContainer2.Panel1.ResumeLayout(False)
        Me.SplitContainer2.Panel2.ResumeLayout(False)
        Me.SplitContainer2.Panel2.PerformLayout()
        CType(Me.SplitContainer2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer2.ResumeLayout(False)
        CType(Me.PictureBox_refresh, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents lvFiles As System.Windows.Forms.ListView
    Friend WithEvents trvFolders As System.Windows.Forms.TreeView
    Friend WithEvents iIconList As System.Windows.Forms.ImageList
    Friend WithEvents cmClipboardOp As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents sourToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents destToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents cboView As System.Windows.Forms.ComboBox
    Friend WithEvents txt_source As System.Windows.Forms.TextBox
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents SplitContainer2 As System.Windows.Forms.SplitContainer
    Friend WithEvents lbl_source As System.Windows.Forms.Label
    Friend WithEvents lbl_destination As System.Windows.Forms.Label
    Friend WithEvents txt_destination As System.Windows.Forms.TextBox
    Friend WithEvents btn_re As System.Windows.Forms.Button
    Friend WithEvents btn_sauv As System.Windows.Forms.Button
    Friend WithEvents BackgroundWorkerDISMCommand As System.ComponentModel.BackgroundWorker
    Friend WithEvents BackgroundWorkerDisMount As System.ComponentModel.BackgroundWorker
    Friend WithEvents BackgroundWorkerMount As System.ComponentModel.BackgroundWorker
    Friend WithEvents btn_dismount As System.Windows.Forms.Button
    Friend WithEvents btn_mount As System.Windows.Forms.Button
    Friend WithEvents txtOutput As System.Windows.Forms.TextBox
    Friend WithEvents lbl_source_info As System.Windows.Forms.Label
    Friend WithEvents lbl_dest_info As System.Windows.Forms.Label
    Friend WithEvents lbl_version As System.Windows.Forms.Label
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents tip_help As System.Windows.Forms.ToolTip
    Friend WithEvents btn_adv As System.Windows.Forms.Button
    Friend WithEvents txt_current_dir As System.Windows.Forms.TextBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox_refresh As System.Windows.Forms.PictureBox
    Friend WithEvents btn_diskpart As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents btn_explorateur As System.Windows.Forms.Button

End Class
